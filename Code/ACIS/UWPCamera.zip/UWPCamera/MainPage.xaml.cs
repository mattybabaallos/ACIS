﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Enumeration;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Imaging;
using Windows.Media.Capture;
using Windows.Media.MediaProperties;
using Windows.Storage;
using Windows.Storage.FileProperties;
using Windows.Storage.Streams;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using System.Threading.Tasks;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWPCamera
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        #region button click handler
        private async void CaptureButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                while (true)
                {
                    #region initialize the MediaCapture
                    MediaCapture mediaCapture = new MediaCapture();
                    await mediaCapture.InitializeAsync();
                    #endregion

                    #region set up the camera preview
                    // capture a photo to a SoftwareBitmap
                    var lowLagCapture = await mediaCapture.PrepareLowLagPhotoCaptureAsync(ImageEncodingProperties.CreateUncompressed(MediaPixelFormat.Bgra8));

                    // capture a photo
                    var capturedPhoto = await lowLagCapture.CaptureAsync();

                    // get a SoftwareBitmap
                    var softwareBitmap = capturedPhoto.Frame.SoftwareBitmap;

                    // done capturing
                    await lowLagCapture.FinishAsync();

                    // covert softwareBitmap to display in xmal
                    if (softwareBitmap.BitmapPixelFormat != BitmapPixelFormat.Bgra8 ||
                       softwareBitmap.BitmapAlphaMode == BitmapAlphaMode.Straight)
                    {
                        softwareBitmap = SoftwareBitmap.Convert(softwareBitmap, BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);
                    }

                    var source = new SoftwareBitmapSource();
                    await source.SetBitmapAsync(softwareBitmap);

                    // Set the source of the Image control
                    CapturedPhoto.Source = source;
                    #endregion

                    #region save photo to a file
                    // get the user's pictures library
                    var myPictures = await StorageLibrary.GetLibraryAsync(KnownLibraryId.Pictures);

                    // get a reference default save folder
                    // CreateFileAsync creates a new StorageFile to which the photo will be saved
                    StorageFile file = await myPictures.SaveFolder.CreateFileAsync("photo.jpg", CreationCollisionOption.GenerateUniqueName);

                    using (var captureStream = new InMemoryRandomAccessStream())
                    {
                        //capture a photo to the stream
                        await mediaCapture.CapturePhotoToStreamAsync(ImageEncodingProperties.CreateJpeg(), captureStream);

                        // create a file stream to the output file
                        using (var fileStream = await file.OpenAsync(FileAccessMode.ReadWrite))
                        {
                            // create a BitmapDecoder to decode the image from the in memory stream 
                            // and then create a BitmapEncoder to encode the image to file by calling CreateForTranscodingAsync.
                            var decoder = await BitmapDecoder.CreateAsync(captureStream);
                            var encoder = await BitmapEncoder.CreateForTranscodingAsync(fileStream, decoder);
                            //encoder.BitmapTransform.Rotation = BitmapRotation.Clockwise180Degrees;

                            // optionally create a BitmapPropertySet object 
                            // and then call SetPropertiesAsync on the image encoder to include metadata about the photo in the image file
                            var properties = new BitmapPropertySet {
                                { "System.Photo.Orientation", new BitmapTypedValue(PhotoOrientation.Normal, PropertyType.UInt16) }
                            };
                            await encoder.BitmapProperties.SetPropertiesAsync(properties);

                            // call FlushAsync on the encoder object to transcode the photo from the in-memory stream to the file.
                            await encoder.FlushAsync();
                        }
                    }
                    #endregion

                    await Task.Delay(TimeSpan.FromSeconds(2));
                }
            }
            catch
            {
                var dialog1 = new MessageDialog("Error");
                await dialog1.ShowAsync();
            }
        }
        #endregion
    }
}
